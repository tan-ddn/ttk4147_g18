#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include <native/task.h>
#include <native/sem.h>h>
#include <native/mutex.h>
#include <sys/mman.h>
#include <sched.h>
#include <native/timer.h>
#include <rtdk.h>

RT_TASK task_L;
RT_TASK task_H;
RT_TASK synch_task;


RT_SEM sem1;
RT_MUTEX mutexA;
RT_MUTEX mutexB;

struct rt_task_info temp;

struct resource
{
   RT_MUTEX *mutex;
   int priority;
};

struct task_priorities
{
   int base_priority;
   int boost_priority;
};

struct resource resourceA;
struct resource resourceB;

int time_unit = 100000;

void check_tasks(struct *resource resource

void busy_wait_us(unsigned long delay){
	for(; delay > 0; delay--){
		rt_timer_spin(time_unit);
	}
}



void function_A1( void *vargp )
{	
        rt_sem_p(&sem1, TM_INFINITE);
	rt_printf("Task Low starts\n");
    	rt_mutex_acquire(&mutexA, TM_INFINITE);
	busy_wait_us(3);

   	rt_mutex_acquire(&mutexB, TM_INFINITE);
	busy_wait_us(3);


	rt_mutex_release(&mutexB);
	rt_mutex_release(&mutexA);

	busy_wait_us(1);
	rt_printf("Task Low ends\n");
}

void function_B1( void *vargp )
{
	rt_sem_p(&sem1, TM_INFINITE);
	rt_task_sleep(time_unit);
	rt_printf("Task High starts\n");
   	rt_mutex_acquire(&mutexB, TM_INFINITE);
        busy_wait_us(1);

	rt_mutex_acquire(&mutexA, TM_INFINITE);
	busy_wait_us(2);

	rt_mutex_release(&mutexA);
	rt_mutex_release(&mutexB);

	busy_wait_us(1);
	rt_printf("Task High ends\n");
}

void synchronization( void *vargp )
{    

 	//rt_printf("Sync function starts\n");
	rt_task_start(&task_L, &function_A1, NULL);
  	rt_task_start(&task_H, &function_B1, NULL);
	rt_task_sleep(1000000000);
	rt_sem_broadcast(&sem1); 
	rt_task_sleep(1000000000);

}

int main(int argc, char* argv[])
{
	
  mlockall(MCL_CURRENT|MCL_FUTURE);
  rt_print_auto_init(1);

// printf("main");
 int a = rt_sem_create(&sem1, "Sem 1", 0, S_PRIO);
 int b = rt_mutex_create(&mutexA, "MutexA");
 int c = rt_mutex_create(&mutexB, "MutexB");
 
 
 resourceA.mutex = &mutexA;
 resourceB.mutex = &mutexB;

 rt_task_create(&task_H, "Task A" , 0, 70, T_CPU(1));
 rt_task_create(&task_L, "Task B" , 0, 50, T_CPU(1));
 rt_task_create(&synch_task, "Sync" , 0, 90, T_CPU(1));

  
  rt_task_start(&synch_task, &synchronization, NULL);

  sleep(5);
  rt_printf("Before Print\n");
  rt_sem_delete(&sem1);
  rt_mutex_delete(&mutexA);
  rt_mutex_delete(&mutexB);


  return 0;

}

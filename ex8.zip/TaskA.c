#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include <native/task.h>
#include <native/sem.h>
#include <sys/mman.h>
#include <sched.h>
#include <native/timer.h>
#include <rtdk.h>

RT_TASK task_A;
RT_TASK task_B;
RT_TASK task_C;

RT_SEM sem1;

void function_A( void *vargp )
{
        rt_sem_p(&sem1, TM_INFINITE);
	rt_printf("Task A is running\n");
    
}

void function_B( void *vargp )
{
	rt_sem_p(&sem1, TM_INFINITE);
	rt_printf("Task B is running\n");  
}


void function_C( void *vargp )
{    

 
	rt_task_start(&task_A, &function_A, NULL);
  	rt_task_start(&task_B, &function_B, NULL);
	sleep(0.1);
	rt_sem_broadcast(&sem1); 
	sleep(0.1);
	rt_sem_delete(&sem1);

}


int main(int argc, char* argv[])
{
	
  mlockall(MCL_CURRENT|MCL_FUTURE);
  rt_print_auto_init(1);

 
 int a = rt_sem_create(&sem1, "Sem 1", 0, S_FIFO);

  rt_task_create(&task_A, "Task A" , 0, 50, T_CPU(1));
  rt_task_create(&task_B, "Task B" , 0, 50, T_CPU(1));
  rt_task_create(&task_C, "Task C" , 0, 70, T_CPU(1));

  
  rt_task_start(&task_C, &function_C, NULL);

	return 0;

}

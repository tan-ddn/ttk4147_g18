#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include <native/task.h>
#include <native/sem.h>h>
#include <native/mutex.h>
#include <sys/mman.h>
#include <sched.h>
#include <native/timer.h>
#include <rtdk.h>

RT_TASK task_A;
RT_TASK task_B;
RT_TASK task_C;
RT_TASK synch_task;


RT_SEM sem1;
RT_MUTEX mutex;

struct rt_task_info temp;


int time_unit = 100000;

void busy_wait_us(unsigned long delay){
	for(; delay > 0; delay--){
		rt_timer_spin(time_unit);
	}
}



void function_A1( void *vargp )
{	
        rt_sem_p(&sem1, TM_INFINITE);
	rt_task_sleep(2*time_unit);
    	rt_mutex_acquire(&mutex, TM_INFINITE);
	rt_printf("Task A starts\n");
        busy_wait_us(2);
	rt_printf("Task A ends\n");
	rt_mutex_release(&mutex);
}

void function_B1( void *vargp )
{
	rt_sem_p(&sem1, TM_INFINITE);
	rt_task_sleep(time_unit);
	rt_printf("Task B starts\n");
        busy_wait_us(5);
	rt_printf("Task B ends\n");

}

void function_C1( void *vargp )
{

	rt_sem_p(&sem1, TM_INFINITE);
    	rt_mutex_acquire(&mutex, TM_INFINITE);
	rt_printf("Task C starts\n");
        busy_wait_us(3);
	rt_printf("Task C ends\n");
	rt_task_inquire(NULL, &temp);
	rt_printf("Base prio: %i, Current prio: %i\n", temp.bprio, temp.cprio);
	rt_mutex_release(&mutex);

}

void synchronization( void *vargp )
{    

 	//rt_printf("Sync function starts\n");
	rt_task_start(&task_A, &function_A1, NULL);
  	rt_task_start(&task_B, &function_B1, NULL);
	rt_task_start(&task_C, &function_C1, NULL);
	rt_task_sleep(1000000000);
	rt_sem_broadcast(&sem1); 
	rt_task_sleep(1000000000);

}
int main(int argc, char* argv[])
{
	
  mlockall(MCL_CURRENT|MCL_FUTURE);
  rt_print_auto_init(1);

// printf("main");
 int a = rt_sem_create(&sem1, "Sem 1", 0, S_PRIO);
 int b = rt_mutex_create(&mutex, "Mutex");


  rt_task_create(&task_A, "Task A" , 0, 70, T_CPU(1));
  rt_task_create(&task_B, "Task B" , 0, 50, T_CPU(1));
  rt_task_create(&task_C, "Task C" , 0, 30, T_CPU(1));
  rt_task_create(&synch_task, "Sync" , 0, 90, T_CPU(1));

  
  rt_task_start(&synch_task, &synchronization, NULL);

	sleep(5);

	rt_sem_delete(&sem1);
	rt_mutex_delete(&mutex);
	
	
	return 0;

}

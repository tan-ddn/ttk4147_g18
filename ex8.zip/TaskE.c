#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#include <native/task.h>
#include <native/sem.h>h>
#include <native/mutex.h>
#include <sys/mman.h>
#include <sched.h>
#include <native/timer.h>
#include <rtdk.h>

RT_TASK task_L;
RT_TASK task_H;
RT_TASK synch_task;


RT_SEM sem1;
RT_MUTEX mutexA;
RT_MUTEX mutexB;

struct rt_task_info temp;

struct resource
{
   RT_MUTEX *mutex;
   int priority;
   char name[20];
};

struct task_prio
{
   int base_prio;
   int boost_prio;
   int current_prio;
};

void icpp_lock(struct resource res, RT_TASK *task)
{

	RT_TASK *curtask;
	RT_TASK_INFO curtaskinfo;

	curtask = rt_task_self();
	rt_task_inquire(curtask, &curtaskinfo);
	
 	rt_mutex_acquire(res.mutex, TM_INFINITE);
	rt_printf("Resource %s is locked by task %s \n", res.name, curtaskinfo.name);
	rt_printf("New Priority %d \n", res.priority);
	int result = rt_task_set_priority(NULL, res.priority);
	rt_printf("Result %d\n", result);

	rt_task_inquire(NULL, &temp);
	rt_printf("Base prio: %i, Current prio: %i\n", temp.bprio, temp.cprio);

//	rt_printf("Priority of task %s is set to %d \n", curtaskinfo.name, res.priority);

}

void icpp_unlock(struct resource res,struct task_prio t_prio)
{
	
	RT_TASK *curtask;
	RT_TASK_INFO curtaskinfo;

	curtask = rt_task_self();
	rt_task_inquire(curtask, &curtaskinfo);

 	rt_mutex_release(res.mutex);
	rt_printf("Resource %s is released by task %s \n", res.name, curtaskinfo.name);
	rt_task_set_priority(&curtask, t_prio.base_prio);
	rt_printf("Priority of task %s is set to %d \n", curtaskinfo.name, t_prio.base_prio);

}



struct resource resourceA;
struct resource resourceB;

struct task_prio taskH_prio;
struct task_prio taskL_prio;

int time_unit = 100000;


void busy_wait_us(unsigned long delay){
	for(; delay > 0; delay--){
		rt_timer_spin(time_unit);
	}
}



void function_L( void *vargp )
{	
        rt_sem_p(&sem1, TM_INFINITE);
      
        icpp_lock(resourceA, &task_L);
	rt_printf("Task Low starts\n");	
	busy_wait_us(3);

   	icpp_lock(resourceB, &task_L);
	busy_wait_us(3);

	icpp_unlock(resourceB, taskL_prio);
	icpp_unlock(resourceA, taskL_prio);

	busy_wait_us(1);
	rt_printf("Task Low ends\n");
}

void function_H( void *vargp )
{
	rt_sem_p(&sem1, TM_INFINITE);
	rt_task_sleep(time_unit);
	
   	
	icpp_lock(resourceB, &task_H);
	rt_printf("Task High starts\n");
        busy_wait_us(1);

	icpp_lock(resourceA, &task_H);
	busy_wait_us(2);

	icpp_unlock(resourceA, taskH_prio);
	icpp_unlock(resourceB, taskH_prio);

	busy_wait_us(1);
	rt_printf("Task High ends\n");
}

void synchronization( void *vargp )
{    
	rt_task_start(&task_L, &function_L, NULL);
  	rt_task_start(&task_H, &function_H, NULL);
	rt_task_sleep(1000000000);
	rt_sem_broadcast(&sem1); 
	rt_task_sleep(1000000000);
}

int main(int argc, char* argv[])
{
	
  mlockall(MCL_CURRENT|MCL_FUTURE);
  rt_print_auto_init(1);

 int a = rt_sem_create(&sem1, "Sem 1", 0, S_PRIO);
 int b = rt_mutex_create(&mutexA, "MutexA");
 int c = rt_mutex_create(&mutexB, "MutexB");
 
 
 resourceA.mutex = &mutexA;
 resourceB.mutex = &mutexB;
 resourceA.priority = 70;
 resourceB.priority = 70;
 
 strcpy(resourceA.name, "Resource A");
 strcpy(resourceB.name, "Resource B");
  
 taskL_prio.base_prio = 50;
 taskH_prio.base_prio = 70;
 
 taskL_prio.boost_prio = 70;
 taskL_prio.base_prio = 70;

 rt_task_create(&task_H, "Task H" , 0, 70, T_CPU(1));
 rt_task_create(&task_L, "Task L" , 0, 50, T_CPU(1));
 rt_task_create(&synch_task, "Sync" , 0, 90, T_CPU(1));

  
  rt_task_start(&synch_task, &synchronization, NULL);

  sleep(15);
  rt_printf("Before Print\n");
  rt_sem_delete(&sem1);
  rt_mutex_delete(&mutexA);
  rt_mutex_delete(&mutexB);


  return 0;

}
